function Order(CardName, Email, Number, CardNumber, ExpirationMonth, ExpirationYear,CVC)
{
   this.CardName = CardName;
   this.Email = Email;
   this.Number = Number;
   this.CardNumber = CardNumber;
   this.ExpirationMonth = ExpirationMonth;
   this.ExpirationYear = ExpirationYear;
   this.CVC = CVC;
}





	  
function ValidateForm(CardName,Email, Number, CardNumber,ExpirationMonth, ExpirationYear, CVC)
{
   
	var letters = /^[A-Za-z\s]+$/;  
	if(CardName.value.match(letters))
	{ 
		var emval = (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/); 
		if(Email.value.match(emval))
		{ return true
			
			var phone = /^([0-9]{10})$/;
			if(Number.value.match(phone))
			{ 
				var cardno = /^([0-9]{16})$/;
				if(CardNumber.value.match(cardno))
				{
					var expmo= /^([0-9]{2})$/;
					if(ExpirationMonth.value.match(expmo))
					{
						var expyr= /^([0-9]{4})$/
						if(ExpirationYear.value.match(expyr))
						{
							var cvchk= /^([0-9]{3})$/
							if(CVC.value.match(cvchk))
							{
							}
							else
							{
							alert('Please enter the 3-digit CVC found on your card!')
							return false;
							}
						}
						else {
						alert('Please enter a 4 digit expiration year!')
						}
					}
					else {
					alert('Please enter a two digit expiration month!');
					return false;
					}
				}
				else {
				alert("Not a valid credit card number! 16 Numeric required");
				return false;
				}
			}
			else {
			alert("Please enter a valid phone number."); 
			return false;
			}
		}
		else {
		 alert('Please enter a valid email!')
		return false;
		}
	}
	else {
	alert('Please enter a valid name.'); 
	return false;
	}

}